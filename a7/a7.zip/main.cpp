void test_operators(int argc, const char** argv);
void test_queries(int argc, const char** argv);

int main(int argc, const char** argv)
{
    test_operators(argc, argv);
    test_queries(argc, argv);
}
