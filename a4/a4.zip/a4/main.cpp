void test_queries(int argc, const char** argv);

int main(int argc, const char** argv)
{
    test_queries(argc, argv);
}
