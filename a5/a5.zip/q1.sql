-- What is the birth date of Tweetii?

select birth_date 
from member
where name = 'Tweetii';